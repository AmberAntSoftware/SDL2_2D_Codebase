#include "../2DBase_defines.h"
#include "components.h"

#define pcase(constFunctionPointer) ((long long int)(& constFunctionPointer))
#define ccase(constFunctionPointer) ((const long long int)(& constFunctionPointer))

void GUI_MouseEnteredOnElement(GUI_Element *element){
    void *data = NULL;
    switch(pcase(data)){
    case(GUI_MouseExitedOnElement):
        break;
    }
    //
}
void GUI_MouseExitedOnElement(GUI_Element *element){
    //
}
void GUI_MousePressedOnElement(GUI_Element *element){
    //
}
void GUI_MouseDraggedOnElement(GUI_Element *element){
    //
}
void GUI_MouseReleasedOnElement(GUI_Element *element){
    //
}
void GUI_MouseMovedOnElement(GUI_Element *element){
    //
}

void GUI_KeyPressedOnElement(GUI_Element *element){
    //
}
void GUI_KeyReleasedOnElement(GUI_Element *element){
    //
}
void GUI_KeyHeldOnElement(GUI_Element *element){
    //
}
